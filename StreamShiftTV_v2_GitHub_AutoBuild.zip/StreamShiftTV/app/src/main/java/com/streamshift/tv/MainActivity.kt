package com.streamshift.tv

import android.app.AlertDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder

data class Channel(
    val name: String,
    val url: String,
    val group: String = "Other",
    val logo: String = "",
    val tvgId: String = ""
)

class MainActivity : AppCompatActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var list: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var categorySpinner: Spinner
    private lateinit var modeSpinner: Spinner
    private lateinit var m3uPanel: View
    private lateinit var xtreamPanel: View
    private val all = mutableListOf<Channel>()
    private val shown = mutableListOf<Channel>()
    private val http = OkHttpClient.Builder().followRedirects(true).build()
    private val prefs by lazy { getSharedPreferences("streamshift", MODE_PRIVATE) }
    private val favorites = mutableSetOf<String>()
    private val recents = mutableListOf<String>()
    private var selectedGroup = "All"
    private var onlyFavorites = false
    private var onlyRecents = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        favorites.addAll(prefs.getStringSet("favorites", emptySet()) ?: emptySet())
        recents.addAll(prefs.getString("recents", "")!!.split("\n").filter { it.isNotBlank() })

        player = ExoPlayer.Builder(this).build()
        findViewById<PlayerView>(R.id.playerView).player = player
        list = findViewById(R.id.channelList)
        categorySpinner = findViewById(R.id.categorySpinner)
        modeSpinner = findViewById(R.id.modeSpinner)
        m3uPanel = findViewById(R.id.m3uPanel)
        xtreamPanel = findViewById(R.id.xtreamPanel)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf<String>())
        list.adapter = adapter

        modeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("M3U Playlist", "Xtream-compatible Login"))
        modeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                m3uPanel.visibility = if (pos == 0) View.VISIBLE else View.GONE
                xtreamPanel.visibility = if (pos == 1) View.VISIBLE else View.GONE
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        findViewById<Button>(R.id.loadM3uButton).setOnClickListener {
            loadPlaylist(findViewById<EditText>(R.id.playlistUrl).text.toString().trim())
        }
        findViewById<Button>(R.id.xtreamButton).setOnClickListener { loadXtream() }
        findViewById<Button>(R.id.allButton).setOnClickListener { onlyFavorites=false; onlyRecents=false; filter() }
        findViewById<Button>(R.id.favButton).setOnClickListener { onlyFavorites=true; onlyRecents=false; filter() }
        findViewById<Button>(R.id.recentButton).setOnClickListener { onlyFavorites=false; onlyRecents=true; filter() }

        list.setOnItemClickListener { _, _, p, _ -> play(shown[p]) }
        list.setOnItemLongClickListener { _, _, p, _ -> toggleFavorite(shown[p]); true }

        findViewById<EditText>(R.id.searchBox).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { filter() }
            override fun afterTextChanged(e: Editable?) {}
        })

        categorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                selectedGroup = p?.getItemAtPosition(pos)?.toString() ?: "All"; filter()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun loadXtream() {
        val server = findViewById<EditText>(R.id.serverUrl).text.toString().trim().trimEnd('/')
        val user = findViewById<EditText>(R.id.username).text.toString().trim()
        val pass = findViewById<EditText>(R.id.password).text.toString()
        if (server.toHttpUrlOrNull() == null || user.isBlank() || pass.isBlank()) {
            toast("Enter a valid server URL, username and password"); return
        }
        val u = URLEncoder.encode(user, "UTF-8")
        val p = URLEncoder.encode(pass, "UTF-8")
        val playlist = "$server/get.php?username=$u&password=$p&type=m3u_plus&output=ts"
        prefs.edit().putString("last_epg_url", "$server/xmltv.php?username=$u&password=$p").apply()
        loadPlaylist(playlist)
    }

    private fun loadPlaylist(url: String) {
        if (url.toHttpUrlOrNull() == null) { toast("Enter a valid http/https playlist URL"); return }
        findViewById<TextView>(R.id.statusText).text = "Loading…"
        lifecycleScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    http.newCall(Request.Builder().url(url).header("User-Agent", "StreamShiftTV/2.0").build())
                        .execute().use { r -> if (!r.isSuccessful) error("HTTP ${r.code}"); r.body?.string().orEmpty() }
                }
                val parsed = parseM3u(text)
                all.clear(); all.addAll(parsed)
                updateGroups(); filter()
                findViewById<TextView>(R.id.statusText).text = "${all.size} channels • ${all.map{it.group}.distinct().size} groups"
            } catch (e: Exception) {
                findViewById<TextView>(R.id.statusText).text = "Load failed"
                toast("Could not load playlist: ${e.message}")
            }
        }
    }

    private fun parseM3u(text: String): List<Channel> {
        val out = mutableListOf<Channel>()
        var name = "Channel"; var group = "Other"; var logo = ""; var tvgId = ""
        val attr = Regex("([A-Za-z0-9_-]+)=\"([^\"]*)\"")
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.startsWith("#EXTINF", true)) {
                name = line.substringAfterLast(',').trim().ifBlank { "Channel" }
                val attrs = attr.findAll(line).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                group = attrs["group-title"].orEmpty().ifBlank { "Other" }
                logo = attrs["tvg-logo"].orEmpty(); tvgId = attrs["tvg-id"].orEmpty()
            } else if (line.isNotBlank() && !line.startsWith("#")) {
                out.add(Channel(name, line, group, logo, tvgId))
            }
        }
        return out
    }

    private fun updateGroups() {
        val groups = mutableListOf("All")
        groups.addAll(all.map { it.group }.filter { it.isNotBlank() }.distinct().sorted())
        categorySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, groups)
        selectedGroup = "All"
    }

    private fun filter() {
        if (!::adapter.isInitialized) return
        val q = findViewById<EditText>(R.id.searchBox).text.toString().trim()
        shown.clear()
        shown.addAll(all.filter { c ->
            val groupOk = selectedGroup == "All" || c.group == selectedGroup
            val searchOk = q.isBlank() || c.name.contains(q, true) || c.group.contains(q, true)
            val modeOk = when { onlyFavorites -> favorites.contains(c.url); onlyRecents -> recents.contains(c.url); else -> true }
            groupOk && searchOk && modeOk
        })
        adapter.clear()
        adapter.addAll(shown.map { c -> (if (favorites.contains(c.url)) "★ " else "") + c.name + "  ·  " + c.group })
        adapter.notifyDataSetChanged()
    }

    private fun play(c: Channel) {
        rememberRecent(c.url)
        findViewById<TextView>(R.id.nowPlaying).text = "NOW PLAYING  •  ${c.name}  •  ${c.group}"
        player.setMediaItem(MediaItem.fromUri(c.url)); player.prepare(); player.play()
    }

    private fun toggleFavorite(c: Channel) {
        if (!favorites.add(c.url)) favorites.remove(c.url)
        prefs.edit().putStringSet("favorites", favorites).apply(); filter()
        toast(if (favorites.contains(c.url)) "Added to favorites" else "Removed from favorites")
    }

    private fun rememberRecent(url: String) {
        recents.remove(url); recents.add(0, url)
        while (recents.size > 30) recents.removeAt(recents.lastIndex)
        prefs.edit().putString("recents", recents.joinToString("\n")).apply()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    override fun onStop() { super.onStop(); player.pause() }
    override fun onDestroy() { player.release(); super.onDestroy() }
}
